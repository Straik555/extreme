export default {
    colors: {
        light: 'white',
        lightSilver: '#c7c7c7',
        greenHeader: '#59abb4',
        titleDark: '#585858',
        categoryLight: '#b2b4b9',
        priceGreen: '#499c49',
    }
}
